# Primary 3 Uranus Android

Android WebView wrapper for the Primary 3 Uranus class schedule.

## Build
The GitHub Actions workflow builds a debug APK using Gradle and Android SDK.
Output: `app/build/outputs/apk/debug/app-debug.apk`

The app opens Zoom URLs in an external app/browser. Lesson notes and attendance are stored locally on the device.
